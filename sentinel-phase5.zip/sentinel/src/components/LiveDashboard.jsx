import PlaceholderSection from './ui/PlaceholderSection'

export default function LiveDashboard() {
  return <PlaceholderSection id="dashboard" name="Live Dashboard" phase="a later phase" />
}
