import { useState } from 'react'
import VideoBackground from './VideoBackground'

/** Designed placeholder for a component image/video. Set `media.image` / `media.video` in data to replace it. */
export default function MediaSlot({ id, label, media }) {
  const [ready, setReady] = useState(false)
  const { image, video } = media || {}
  return (
    <div className="st-media" data-slot={id} data-ready={ready ? '' : undefined}>
      {image && (
        <img
          src={image}
          alt=""
          loading="lazy"
          onLoad={() => setReady(true)}
          onError={(e) => { e.currentTarget.style.display = 'none' }}
        />
      )}
      {video && <VideoBackground src={video} overlay={false} onReady={() => setReady(true)} />}
      {!ready && (
        <div className="st-media-hint">
          <span className="st-mono">{label}</span>
          <span className="st-mono">MEDIA SLOT / {id}</span>
        </div>
      )}
    </div>
  )
}
