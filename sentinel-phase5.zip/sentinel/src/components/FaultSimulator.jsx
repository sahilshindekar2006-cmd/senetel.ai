import PlaceholderSection from './ui/PlaceholderSection'

export default function FaultSimulator() {
  return <PlaceholderSection id="simulator" name="Fault Simulator" phase="a later phase" />
}
