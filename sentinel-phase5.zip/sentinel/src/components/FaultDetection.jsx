import PlaceholderSection from './ui/PlaceholderSection'

export default function FaultDetection() {
  return <PlaceholderSection id="fault-detection" name="Fault Detection" phase="a later phase" />
}
