import { Fragment, useState } from 'react'
import useStickyProgress, { rv } from '../hooks/useStickyProgress'
import VideoBackground from './ui/VideoBackground'
import { ASSEMBLY_LAYERS, STORY_VIDEOS, TONE_COLOR } from '../data/hardwareStory'

export default function ExplodedAssembly() {
  const ref = useStickyProgress()
  const [hasVideo, setHasVideo] = useState(false)
  const last = ASSEMBLY_LAYERS.length - 1
  return (
    <section id="assembly" ref={ref} className="st-wrap" style={{ height: '300svh' }}>
      <div className={`st-stage${hasVideo ? ' st-has-video' : ''}`}>
        {/* Drop public/videos/assembly.mp4 in later: when it loads, it replaces the exploded fallback. */}
        <VideoBackground
          src={STORY_VIDEOS.assembly}
          overlay={false}
          className="absolute inset-0 st-bgvid"
          onReady={() => setHasVideo(true)}
        />
        <div className="st-shade" aria-hidden="true" />
        <div className="st-inner st-asm">
          <div>
            <h2 className="st-h">
              <span className="st-rve st-blk" style={rv(0.3, 0.4)}>EVERY SIGNAL</span>
              <span className="st-rve st-blk" style={rv(0.45, 0.4)}>HAS A SOURCE.</span>
            </h2>
            <p className="st-mono st-rv st-final" style={rv(0.84, 0.1)}>SEVEN PARTS / ONE DEVICE</p>
          </div>
          <div className="st-plates">
            {ASSEMBLY_LAYERS.map((l, i) => (
              <Fragment key={l.id}>
                <div className="st-plate" style={{ '--s': 0.06 + i * 0.13, '--o': i - 2, '--tone': TONE_COLOR[l.tone] }}>
                  <span className="st-mono">{l.label}</span>
                  <span className="st-mono st-plate-note">{l.note}</span>
                </div>
                {i < last && <span className="st-conn" style={{ '--s': 0.16 + i * 0.13 }} />}
              </Fragment>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
