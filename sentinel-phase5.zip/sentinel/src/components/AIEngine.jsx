import PlaceholderSection from './ui/PlaceholderSection'

export default function AIEngine() {
  return <PlaceholderSection id="ai-engine" name="AI Engine" phase="a later phase" videoSlot="/videos/ai.mp4" />
}
