import PlaceholderSection from './ui/PlaceholderSection'

export default function FinalCTA() {
  return <PlaceholderSection id="cta" name="Final CTA" phase="a later phase" />
}
