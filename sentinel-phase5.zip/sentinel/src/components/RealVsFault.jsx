import PlaceholderSection from './ui/PlaceholderSection'

export default function RealVsFault() {
  return <PlaceholderSection id="real-vs-fault" name="Real vs Fault" phase="a later phase" />
}
